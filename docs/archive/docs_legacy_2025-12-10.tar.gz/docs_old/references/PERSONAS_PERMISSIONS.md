# Personas & Permissions Matrix

Aligns user archetypes with Supabase Auth roles and the capabilities exposed by the BurBuriuok platform.

## Personas

| Persona         | Description                                                                                       | Primary Goals                                           | Typical Devices                        |
| --------------- | ------------------------------------------------------------------------------------------------- | ------------------------------------------------------- | -------------------------------------- |
| Learner         | Student preparing for LBS skipper exams; consumes curriculum, tracks progress, practices quizzes. | Build knowledge, stay motivated, review weak topics.    | Mobile (90%), Tablet (10%).            |
| Contributor     | Advanced learner or assistant instructor who will propose content once contributor scope reopens. | Suggest improvements, flag issues for admins to review. | Mobile + occasional desktop.           |
| Admin           | Curriculum maintainer/instructor of record and the only current media uploader.                   | Keep data accurate, manage media, monitor analytics.    | Desktop (primary), Tablet (secondary). |
| Visitor (Guest) | Unauthenticated user browsing sample content.                                                     | Evaluate the tool, read basics.                         | Mobile web.                            |

## Role Mapping

Supabase Auth `app_role` custom claim drives API policies.

| Role                   | Personas    | Capabilities                                                                                        |
| ---------------------- | ----------- | --------------------------------------------------------------------------------------------------- |
| `guest` (default)      | Visitor     | Read-only access to public endpoints (curriculum, concepts, search). No data writes.                |
| `learner`              | Learner     | Everything in `guest` + progress management, study queue, quiz submissions.                         |
| `contributor` (future) | Contributor | Same as `learner` plus ability to propose edits and limited moderation preview once re-enabled.     |
| `admin`                | Admin       | Full CRUD on curriculum/concepts/media, access to audit logs, configure study paths, manage badges. |

Authentication flow:

1. Anonymous navigation allowed (role `guest`).
2. Supabase magic-link login is the only sign-in path; backend sets session with `app_role='learner'` unless the email belongs to the admin allowlist.
3. Admin invitations ship with AUTH-002, consolidating allowlist management alongside learner profile bootstrap.
4. Device-key progress syncing remains available (role `guest`) until AUTH-003 lands the migration/sunset tooling.

## API Permissions Summary

| Endpoint Namespace                     | Guest | Learner | Contributor (future) | Admin |
| -------------------------------------- | ----- | ------- | -------------------- | ----- |
| `/curriculum`, `/concepts`, `/search`  | ✅    | ✅      | ✅                   | ✅    |
| `/progress`, `/study-queue`            | ❌    | ✅      | ✅                   | ✅    |
| `/media-submissions` (deferred)        | ❌    | ❌      | ❌                   | ❌    |
| `/admin/curriculum`, `/admin/concepts` | ❌    | ❌      | ❌                   | ✅    |
| `/admin/media`                         | ❌    | ❌      | ❌                   | ✅    |
| `/admin/audit`                         | ❌    | ❌      | ❌                   | ✅    |
| `/study-paths` (enrol/complete)        | ❌    | ✅      | ✅                   | ✅    |
| `/practice` (quiz results)             | ❌    | ✅      | ✅                   | ✅    |

Legend: ✅ full access; ❌ denied. `/media-submissions` endpoints return once contributor scope resumes.

## Row-Level Security (RLS) Considerations

- `concept_progress`, `study_queue`, `gamification_*`, `study_path_assignments`: rows restricted to matching `auth.uid()` or `device_key` hashed to session.
- `media_assets`: only admins insert/select during the media MVP; learner/contributor policies resume when contributor uploads return.
- `content_versions`, `media_reviews`: remain admin-only until moderation flow reactivates.

## Audit & Escalation

- Admins will receive moderation digests once contributor uploads relaunch; paused during admin-only MVP.
- Learner flagging via `/media-submissions` deferred until contributor scope resumes.
- Contributor role will require review/approval before elevation (`profiles.role = 'contributor'`).
- Monitor magic-link adoption metrics during the AUTH-001/002 rollout and defer any device-key policy changes until AUTH-003 is complete.

## Open Questions

- Do we allow self-service upgrade from learner to contributor, or is it invite-only?
- Should guests have limited progress saving via device key without auth? (Potential for future anonymous progress mode.)
- How do we expire inactive admin accounts (policy & automation)?

## Admin Route Enforcement

- **Frontend Guard**: The `/admin` SvelteKit layout reads the Supabase session during `load()`, asserts `app_role === 'admin'`, renders persona banner for authorised users, and surfaces friendly guidance for everyone else.
- **Backend Middleware**: Express middleware `requireAdminRole` checks the decoded JWT claim (`app_role`) for every `/admin/**` endpoint. Requests failing the check return HTTP 401/403 and are logged for analytics (ADM-001).
- **Telemetry**: Both layers emit `admin_session_checked` events (console + `CustomEvent`) containing decision outcome, role, and email to support upcoming ADM-005 analytics work.
- **Allowlist Management**: Until AUTH-002 lands, maintain admin emails via the Supabase dashboard (Auth → Users → Add user). The auth backlog replaces this with an invite console backed by the `profiles` table and documented auditing.
