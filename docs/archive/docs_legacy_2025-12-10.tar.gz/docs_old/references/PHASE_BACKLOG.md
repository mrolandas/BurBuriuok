# Phase 0 / Phase 1 Backlog Outline

Use this backlog to spin issues or PR scopes. Keep items focused on thin slices that ship incremental value and unblock later phases.

## Phase 0 – Platform Foundation

- [ ] **Prerequisite graph modelling** – finalise table design (`curriculum_dependencies`) and extend seed builder to populate edge data; include Supabase migration + regeneration workflow (ref: `docs/references/SCHEMA_DECISIONS.md`).
- [ ] **Draft/publish workflow scaffolding** – create `content_versions` tables, triggers, and API contracts for status transitions; document moderation states (ref: `docs/references/SCHEMA_DECISIONS.md`).
- [x] **Canonical concept pipeline** – centralise content in `docs/static_info/LBS_concepts_master.md`, ensure `npm run content:seed:generate` regenerates seeds, and document the workflow in setup guides.
- [ ] **API surface spike** – stub backend endpoints for read/progress/admin access with contract tests.
- [ ] **Developer experience hardening** – wire lint/test commands, seed scripts, and Supabase CLI workflows into CI (lint + seed regeneration gate).

## Phase 1 – Content Management & Moderation

- [ ] **Admin CRUD UI** – build editable grids/forms for nodes, items, concepts, and dependencies with validation feedback.
- [ ] **Content versioning UX** – implement draft → review → publish flow, surfaced in admin dashboard with change history.
- [x] **Media ingestion pipeline** – admin-only uploads shipped (bucket, metadata, rate limits, UI workflows); contributor moderation stays deferred (ref: `docs/references/SCHEMA_DECISIONS.md`, `docs/references/MODERATION_SLA.md`).
- [ ] **Moderation queue** – queue view with approve/reject actions, audit trail, and notification hooks (ref: `docs/references/MODERATION_SLA.md`).
- [ ] **Automated validation suite** – server-side checks for duplicate ordinals, missing translations, orphan dependencies, and content diffs.
- [ ] **Role-based controls** – enforce permissions per persona (`PERSONAS_PERMISSIONS.md`) within UI and API.

## Curriculum Navigation Components (Learner Experience)

- [ ] **Section board layout** – responsive grid/list that surfaces top-level sections, progress badges, and CTA to drill down; include touch-friendly affordances.
- [ ] **Collapsible tree** – lazy-load nested nodes/items, highlight prerequisites, and expose quick links to concept detail.
- [ ] **Dependency indicators** – inline badges/pills showing required prerequisites, availability state, and links to remaining concepts.

## Concept View Structure

- [ ] **Content header** – title, LT/EN terms, required flag, and curriculum breadcrumb.
- [ ] **Definition & media** – stacked definition, expandable glossary context, and media carousel for approved assets.
- [ ] **Prerequisite & next-step drawers** – collapsible cards summarising dependencies, recommended follow-ups, and outstanding tasks.
- [ ] **Action bar** – buttons for “mark mastered”, “needs review”, “add note”, with keyboard shortcuts and analytics events.

## Study Queue Interactions

- [ ] **Queue manager UI** – backlog of scheduled concepts (Ready, Needs Review, Completed) with swipe/keyboard shortcuts.
- [ ] **Session runner** – timed study mode with confidence prompts and on-the-fly queue updates.
- [ ] **Review outcomes sync** – persist queue state to Supabase (`concept_progress` plus future streak metrics) and broadcast updates via realtime if enabled.

## Automation & Regression Guards

- [x] **Seed regeneration check** – CI job (`.github/workflows/content-seed-guard.yml`) and Husky pre-commit hook ensure `npm run content:seed:check` fails on drift (details in `docs/TESTING_GUIDE.md`).
- [x] **Curriculum snapshot** – CI + pre-commit guard (`npm run content:snapshot:check`) refreshes `docs/static_info/curriculum_in_supabase.csv` and fails on drift (workflow: `content-seed-guard.yml`).
- [x] **Concept content tests** – `npm run content:markdown:validate` lints `docs/static_info/LBS_concepts_master.md` for column/schema issues and runs in the same guard pipeline.
