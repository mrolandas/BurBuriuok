# Admin Setup & Console Blueprint

Captured screens, flows, and access mechanics for the BurBuriuok admin console. These artefacts guide backend API prioritisation, frontend layout decisions, and the new inline editing toggle that lets admins step into learner pages without extra navigation.

## Navigation Structure

1. **Overview** – snapshot of pending tasks and global stats.
2. **Curriculum** – tree editor for nodes/items and dependency management.
3. **Concepts** – data table filtered by section, status, and updated date.
4. **Media Library** – admin-managed uploads and concept attachments.
5. **Audit Log** – chronological list of recent changes with diff previews.
6. **Settings** (later) – manage quotas, integrations, and instructor roles.

A persistent sidebar highlights counters (e.g., Pending media: 5). Admins can collapse it on mobile; each module provides quick actions at the top.

## Sprint 1 Deliverables

The initial admin milestone targets a thin vertical slice that exercises authentication, CRUD, and moderation workflows.

1. **ADM-001 – Secure Admin Shell**: Gate `/admin` routes via Supabase session claims (`app_role='admin'`), provide fallback copy for non-admins, and surface a lightweight status banner showing active persona/role.
2. **ADM-002 – Concept Editor MVP**: Render the Concepts data grid with create/edit drawer, Zod validation shared with backend, draft/publish toggle, and audit-log hook firing `content_versions` entries. _Status: backend endpoints and drawer MVP shipped; polish items pending (data grid filters, optimistic updates, full history sidebar)._
3. **ADM-003 – Moderation Queue List**: Deferred – returns once contributor uploads are back in scope.
4. **ADM-004 – Notification Stubs**: Deferred with ADM-003; no moderation notifications required for admin-only uploads.
5. **ADM-005 – Analytics Mapping Notes**: Document which admin actions emit analytics events so instrumentation can follow; include media upload events once endpoints ship.

Each deliverable should land behind feature flags where possible so the learner experience remains unaffected while the admin surface evolves.

_Update 2025-11-06:_ ADM-001 guard is live – `/admin` layout now displays persona banner for authorised users, renders guidance for learners, and pairs with the Express `requireAdminRole` middleware + telemetry hook.

_Update 2025-11-06 (p.m.)_: ADM-002 admin slice deployed concept CRUD MVP – `/api/v1/admin/concepts` exposes list/detail/upsert endpoints, the SvelteKit console ships the create/edit drawer with shared Zod validation, and audit logging now records each save into `content_versions`.

_Update 2025-11-06 (late)_: Inline concept editing and the persistent “Aktyvuoti Admin” toggle in `AppShell` now mirror the `impersonate=admin` query flag, keeping admin affordances active while navigating between learner pages.

_Update 2025-11-09_: Curriculum tree admin UX now supports drag-and-drop reordering with cancel/apply confirmation banner, auto-expands nodes when presenting delete/edit prompts, reinstates “Pridėti poskyrį”, and wires “Pridėti terminą” into new item/concept CRUD (LT/EN copy, source, required flag) while keeping pending highlights accurate after confirmation.

_Update 2025-11-10_: Concept editing now includes a dedicated modal that mirrors the inline editor (shared helpers, draft/publish buttons, status chip), tree branches refresh immediately after saves, and curriculum admin toolbar buttons adopt the same styling/order as concept actions (arrows first, delete anchored last).

_Update 2025-11-11_: Section board inline editing landed on the learner homepage. When admin mode is active the root cards expose a “Redaguoti skiltį” action that opens the shared modal, posts updates through the curriculum node endpoint, and displays toast feedback after saves.

_Update 2025-11-13_: Concepts history drawer now shows version snapshots and offers a Supabase-authenticated “Atkurti” action that rolls the concept and its linked curriculum item back to the selected version, logging the rollback in `content_versions`.

_Update 2025-11-13 (p.m.)_: Admin saves now persist working copies in `burburiuok.content_drafts` (auto-reconciled by the backend audit logger) and Supabase RLS ensures only admin/service-role sessions can access draft + version history tables.

_Update 2025-11-13 (late)_: Added automated smoke coverage via `npm run test:db002` to verify draft → publish flows, `content_drafts` cleanup, and version snapshots after migrations or policy changes. Reference `docs/TESTING_GUIDE.md` for execution cadence.

_Update 2025-11-13 (evening)_: Concept manager now includes a section/status/search toolbar with empty-state guidance, hides the global AppShell search while in the admin shell, and applies optimistic updates to the drawer saves (falling back to a refetch on Supabase errors).

_Update 2025-11-13 (late night)_: Concept save toasts now echo the resulting publication status and mention when active filters hide the entry, while validation and Supabase failures show actionable guidance inside the drawer alert.

_Update 2025-11-16_: Concept manager extracted its toolbar/list/drawer into `components/ConceptFilters.svelte`, `components/ConceptList.svelte`, and `components/ConceptEditorDrawer.svelte` backed by shared types in `types.ts`, clarifying extension points and reducing churn in the route file.

_Update 2025-11-17_: Media roadmap MVP rescoped to admin-only uploads. The console will surface a lightweight “Pridėti mediją” action inside the concept editor, with moderation queue + SLA tooling deferred until contributor submissions return.

_Update 2025-11-20_: Admin media workspace now supports metadata edits (concept reassignment, title, LT/EN captions) inside the detail drawer with Lithuanian validation copy, introduces a modal preview for images/videos with ESC/backdrop handling, and adds a timed delete confirmation bar to prevent accidental removals.

## Screen Details

### 1. Overview

- **Hero cards**: Pending media, Draft concepts, Dependencies needing review (warnings for orphan nodes or circular refs).
- **Activity feed**: Latest 10 actions from `content_versions` and upcoming media uploads (once API emits events).
- **Shortcuts**: Buttons to create a new concept, add a curriculum node, or review pending media.
- **System health** (future): Supabase status, seed version hash.

### 2. Curriculum Editor

- **Tree panel**: Expandable curriculum tree with ordinals, prerequisites badges, and quick filters (topics, sections, search by code/title).
- **Details pane**: Editing form for selected node item (title, summary, ordinal, parent). Includes dependency tab to add/remove prerequisites.
- **Validation alerts**: Inline warnings when ordinals collide, missing translations detected, or orphaned children exist.
- **Bulk actions**: Reorder within parent, move subtree to a new parent, export subtree CSV.

### 3. Concept Manager

- **Data grid**: Columns for term (LT/EN), status (draft, published, archived), required flag, curriculum mapping, last edit timestamp.
- **Filters**: Section, text search, status toggle, required-only.
- **Row actions**: View, edit (opens modal or full-page editor), duplicate to create variants, archive.
- **Editor**: Multi-step form capturing core definition, translations, metadata, coverage (linked items + dependencies). Displays preview panes for learners.
- **Version history**: Sidebar listing `content_versions` entries with diff preview before publish.
- **Implementation note**: `ConceptManager.svelte` now orchestrates `ConceptFilters`, `ConceptList`, and `ConceptEditorDrawer`, passing shared types from `types.ts` so filter/list/drawer logic can evolve independently of the route skeleton.

### 4. Media Library (Admin Uploads)

- **Entry point**: “Pridėti mediją” button in the concept editor drawer opens an upload dialog limited to admin users.
- **Upload dialog**: Select file (image/video) or paste external URL, choose display title, captions (LT/EN), and optional attribution. Required-field alerts now use Lithuanian copy and render via the shared drawer alert.
  - **Backend handshake**: Calls `POST /api/v1/admin/media` with `source.kind='upload'` (file metadata + size/type) or `source.kind='external'` (curated HTTPS link). Upload responses include `upload.url/token/path` for direct PUT to Supabase; external entries skip the upload step and store `external://` sentinel paths.
- **Attachment list**: Shows existing media for the concept with thumbnail, type, and quick actions (copy embed link, delete, replace). Drawer shortcut honours the locked concept ID.
- **Signed URL helper**: Copy button that generates a 1-hour signed URL for manual testing.
  - Implementation detail: hits `GET /api/v1/admin/media/:id/url?expiresIn=3600`, which returns `{ kind: 'supabase-signed-url', url, expiresAt }` for binaries or `{ kind: 'external', url }` for curated links.
- **Media workspace table**: Checkbox column enables multi-select, a selection toolbar surfaces bulk delete, and row clicks continue to open the detail drawer. Signed URL previews render inline (image, MP4, or embedded YouTube/Vimeo) so admins can verify assets before publishing.
- **Detail drawer**: Editing form mirrors backend validation, trims metadata, and prevents empty submissions. Concept selector honours locked state when launched from a concept, Lithuanian error copy matches shared Zod messages, successful saves emit `[media] asset_updated` toasts while keeping the list entry in sync, and delete actions require a timed (10s) confirmation before the asset is removed.
- **Preview modal**: Clicking the image thumbnail or the video “Peržiūrėti visame lange” button opens a dialog that traps focus, pauses active videos on close, supports ESC/backdrop dismiss, and re-focuses the triggering element for accessibility.
- **Bulk actions**: After triggering bulk delete, the list reports partial failures, clears removed items from the selection set, and refreshes the table + concept attachment panel automatically.
- **Deferred items**: Contributor submissions, moderation tabs, and SLA badges move back into scope when MEDIA-003/004 resume.

**Attaching media to a concept**

1. Open a concept in the admin editor and scroll to the “Papildoma medžiaga” panel.
2. Review the existing attachments; thumbnails open previews in the media workspace if deeper inspection is needed.
3. Click “Pridėti mediją” to launch the media creation drawer with the current concept locked in the selector.
4. Choose **Įkelti** for new files or **Išorinis šaltinis** for curated embeds, complete required metadata (including Lithuanian validation copy where prompted), and submit.
5. Wait for the success toast—on completion the attachment list refreshes automatically and the `/admin/media` workspace reflects the new asset without reloading.

**Managing or removing attachments**

1. From the attachment list, use the action menu to open an item in the media workspace, copy a signed URL, or start deletion.
2. When deleting, confirm the prompt; the detail drawer displays a 10-second confirmation banner, successful removal raises a toast, clears the item from the concept panel, and updates the workspace table in the background.
3. For multiple clean-up tasks, switch to `/admin/media`, select assets via the checkbox column, and use the bulk delete toolbar; partial failures surface inline and surviving selections reset so follow-up actions are clear.

### 5. Audit Log

- **Filters**: Entity type (node, concept, media), status, date range, author.
- **Timeline view**: Items show summary (`Concept “Priekis” updated by Ona`), timestamp, link to details.
- **Diff viewer**: JSON Patch or 2-column view to inspect changes before/after.
- **Export**: CSV export for compliance reviews.

## Cross-Cutting UX Patterns

- Toast notifications for success/failure referencing entity slug/code.
- Optimistic updates where safe; roll back on Supabase error.
- Unsaved changes guard when navigating between forms.
- Inline RLS status indicator (if a save fails due to policy).
- Selection toolbars collapse automatically after multi-select actions so admins get immediate feedback without manual resets.

## Global Admin Mode Toggle

- `AppShell` exposes a menu button labelled “Aktyvuoti Admin” that flips to “Deaktyvuoti Admin” when active. The control is gated behind the same impersonation feature flags used by local development.
- The toggle writes to `src/lib/stores/adminMode.ts`, a persisted Svelte store that ensures admin affordances survive navigation and reloads.
- Toggling the control updates the `impersonate=admin` query parameter via SvelteKit’s `goto`, allowing inline concept and section editing to reuse the existing admin APIs without a page refresh.
- When a Supabase session reports `app_role='admin'`, AppShell now auto-enables the toggle so authenticated admins land directly in edit mode without manually flipping the switch (they can still deactivate it for safe browsing).
- Future authentication work will swap the toggle for a real login dialog while preserving the shared store so the UI remains reactive.

## Access Control & Routing

- **SvelteKit Layout Guard**: Wrap `/admin/+layout.svelte` with a load function that reads the Supabase session, verifies `app_role`, and redirects to `/` with a friendly message when access is denied. During development, allow a query flag (`?impersonate=admin`) gated behind `VITE_ENABLE_ADMIN_IMPERSONATION` to preview layouts without real credentials.
- **Backend Assertion**: All `/admin/**` API calls must re-check the role server-side (Express middleware) to prevent forged client state from bypassing policies.
- **Allowlist**: Maintain the initial admin list inside Supabase Auth (dashboard-managed). Document the steps in `docs/references/PERSONAS_PERMISSIONS.md` and keep a fallback JSON allowlist for local development.
- **Telemetry**: Emit `admin_session_checked` events (ADM-005) when access is granted or denied to monitor health.
- **Global toggle**: Inline impersonation relies on the `adminMode` store keeping the query string in sync. When real authentication replaces the dev flag, ensure the toggle (or future login CTA) continues to update that store so concept pages react immediately.

## Technical Dependencies

- Consumes endpoints documented in `docs/references/API_CONTRACTS.md` (admin namespace).
- Requires real-time updates (optional) to reflect new submissions; fallback poll every 60s.
- Relies on Supabase Auth role claims to render admin-only components.

## Open Questions

- Should instructors have a limited dashboard view (read-only analytics, ability to flag content)?
- How do we surface dependency conflicts best (graph view vs. inline list)?
- Do we need draft scheduling (publish at future date) in the first release?
- What moderation SLA should be communicated to contributors after submission?
