# Current Session Plan – Auth & Progress Kickoff (2025-11-25)

With media MVP complete, this session pivots to authentication, admin user management, and learner progress tracking. Everything else moves to the removed-scope log (`docs/REMOVED_FROM_SCOPE.md`).

## Orientation Checklist

- Review `docs/references/ISSUE_TRACKER.md` for the active AUTH and PROG tickets.
- Confirm Supabase auth prerequisites (`PERSONAS_PERMISSIONS.md`, `API_CONTRACTS.md`, `SCHEMA_DECISIONS.md`) and identify missing migrations.
- Audit current admin tooling to ensure the forthcoming user management surface slots cleanly into `/admin` without regressing existing flows.
- Inventory progress data touchpoints (device-key usage, concept completion events) before drafting the new persistence model.

## Objectives for This Block

- Ship the authentication foundation (magic-link login, role claims) and expose an admin UI for inviting/revoking users.
- Design and implement core learner progress tracking (storage model, API endpoints, admin insight views).
- Retire deferred work items from active docs, capturing them in `docs/REMOVED_FROM_SCOPE.md` for future review.
- Keep reference material (`MASTER_PLAN.md`, `ISSUE_TRACKER.md`, `PERSONAS_PERMISSIONS.md`) aligned with the tightened scope.

## Immediate Focus (week of 2025-11-25)

- Finalise AUTH-001 requirements (environment variables, Supabase config, login UX) and update developer setup notes accordingly.
- Draft the admin user management console requirements (invite list, role toggles, audit trail) and capture acceptance criteria in the tracker.
- Model the progress tracking schema (tables, events, API contracts) and prototype the Supabase migrations needed for PROG-001.
- Prepare QA coverage updates: document auth flow smoke tests and progress persistence checks for `docs/TESTING_GUIDE.md`.

## Detailed Execution Plan – Auth & User Work

### Step 0 – Pre-flight Alignment (0.5 day)

**Findings (2025-11-25):**

- `.env` already carries `SUPABASE_URL`, `SUPABASE_ANON_KEY`, and `SUPABASE_SERVICE_ROLE_KEY`; Supabase CLI v2.62.5 is installed and authenticated (`npx supabase projects list` shows the linked `zvlziltltbalebqpmuqs` project). `npx supabase status` currently expects a local Docker stack (`supabase start`) which is intentionally offline—documented in `docs/DEVELOPMENT_SETUP.md` as optional.
- Admin guard snapshot: frontend `frontend/src/lib/admin/session.ts` still returns the canonical `AdminSessionState` reasons (`missing-session`, `insufficient-role`, etc.) and backend `backend/src/middleware/requireAdminRole.ts` verifies `app_role` via the service client, falling back to the impersonation header when `ADMIN_DEV_IMPERSONATION` is set. This baseline will be referenced after the auth refactor.
- Device-key audit: hosted `burburiuok.concept_progress` currently has 0 rows (queried via service-role client). We will seed representative device-key progress once the learner UI resumes writes so AUTH-003 migration tooling has sample data.

### Step 1 – AUTH-001 Magic-Link Foundation (2–3 days)

2025-11-25: Step 0 pre-flight complete – verified Supabase env/CLI state, captured admin guard baseline, and confirmed `concept_progress` has zero device-key rows ahead of AUTH-003 planning.
2025-11-26: Backend `/api/v1/auth/magic-link` + `/session` routes landed with redirect sanitisation + rate limits, AppShell now reflects Supabase sessions (login/callback flows + logout) and docs gained the new auth env instructions.
2025-11-26: AppShell polish complete – duplicate email row removed from the dropdown, non-admin accounts no longer see "Admin pultas", sign-out sits at the bottom with accent styling, and Render env + include-path expectations captured for deploy readiness.

2. **Infrastructure & config**

- Extend `frontend/static/env.js` (written during deploy) to include `supabaseUrl`/`supabaseAnonKey` sanity validation so `appConfig.supabase` never boots with blanks.
- Add `AUTH_REDIRECT_URL` + `AUTH_EMAIL_FROM` to `.env`, reference them inside `backend/src/routes/auth.ts` (new) for callback verification.

3. **Backend surface**
   - Create `backend/src/routes/auth.ts` with endpoints:
     - `POST /api/v1/auth/magic-link` – proxies Supabase `auth.signInWithOtp` using service client (`getSupabaseClient({ service: true })`).
     - `GET /api/v1/auth/session` – returns the decoded `req.authUser` (mirrors `/admin/status` but for learners) so the frontend can bootstrap the auth store.
   - Wire the new router inside `backend/src/routes/index.ts` ahead of `requireAdminRole` block since learners must hit it unauthenticated.
   - Update rate-limiter middleware to key off `req.ip` for auth requests, preventing spam.
4. **Frontend UX**
   - Introduce `frontend/src/lib/stores/authStore.ts` (Svelte store) that wraps `getSupabaseClient().auth` and mirrors session state to components (AppShell user dropdown, future profile page).
   - Add `/auth/login/+page.svelte` flow reusing existing AppShell layout; include email form, success state, and resend guard.
   - Add `/auth/callback/+page.server.ts` to read the `code` + `type` params generated by Supabase and finalize the session via `supabase.auth.exchangeCodeForSession`.
   - Reuse `AppShell` button slots: hide the placeholder “Prisijungti / Registruotis” navigation once the auth store reports a learner session; show current email + “Atsijungti”.
5. **Role claim propagation**
   - Configure Supabase Auth policy to inject `app_role` claim based on email allowlist table (`admin_allowlist`) until profiles exist. Reference this claim in `frontend/src/lib/admin/session.ts` (already reading `session.user.app_metadata.app_role`).
   - Add `backend/src/middleware/requireLearnerRole.ts` to guard upcoming learner write APIs (progress) while device-key fallback remains.
6. **Docs + QA**
   - Update `docs/TESTING_GUIDE.md` with new smoke tests: request magic-link, follow callback, confirm Supabase session persists, hit `/admin/status`.
   - Extend `docs/references/API_CONTRACTS.md` to cover the new `/auth/*` endpoints and expected error codes.

### Step 4 – AUTH-003 Device-Key Coexistence & Sunset Toolkit (2 days)

1. **Telemetry + monitoring**
   - Instrument `backend/src/routes/progress.ts` so each GET/PUT emits whether it used `deviceKey` or learner `authUser`. Log to structured telemetry sink (stdout for now).
   - Add Supabase view that aggregates progress rows by `device_key` vs `user_id`.
2. **Migration utilities**
   - Create script `scripts/migrateDeviceProgress.ts` (Node) that maps `concept_progress` entries from anonymous keys to authenticated profiles by matching hashed device key stored in `profiles.device_key_hash` (populate this when the learner first signs in).
   - Add dry-run mode writing to `logs/device-progress-migration-<timestamp>.json` so we can audit potential collisions.
3. **Feature flag + rollout**
   - Introduce `.env` flag `ALLOW_DEVICE_KEY_WRITES` read inside `backend/src/routes/progress.ts`; default true, but allow per-environment override as adoption grows.
   - Update `docs/MASTER_PLAN.md` appendix with step-by-step cutover timeline and rollback plan.

### Step 5 – PROG-001 / PROG-002 Dependencies (sketch)

- Once learners authenticate:
  - Update `concept_progress` schema to include `user_id` nullable column; adapt `data/repositories/progressRepository.ts` to upsert by `(user_id, concept_id)` when auth is present, falling back to `device_key` otherwise.
  - Extend backend progress routes to read from `req.authUser` when available. Preserve backwards-compatible response shape for now.
  - Draft admin `/admin/progress` route that surfaces aggregate stats required by PROG-003; rely on `adminFetch` to reuse existing guard infra.
- Document resulting QA matrix (anonymous vs authenticated) inside `docs/TESTING_GUIDE.md` and add seeds to `tests/progress` fixtures for both pathways.

## Planning Deliverables

- **Auth implementation brief** – Secrets checklist, migration plan, and UX outline for AUTH-001→002.
- **Admin user management spec** – Wireframe notes plus API + UI requirements for the new `/admin/users` surface.
- **Progress tracking plan** – Data model, API endpoints, and analytics hook list for PROG-001/002.
- **Scope change log** – Populate `docs/REMOVED_FROM_SCOPE.md` and cross-link from master docs.

## Decisions Locked (2025-11-25)

- Media enhancements beyond the MVP (embeds, analytics, contributor flows) are out of scope until auth + progress land.
- Authentication work takes precedence: no further learner UX features will start until AUTH-001→003 and the user management console ship.
- Progress tracking replaces the queued learner-flow experiments; queue/quiz initiatives return only after persistence is stable.

## Remaining Risks

- Supabase auth introduces new operational burden (token rotation, invite flows). Without a thorough runbook we risk production support gaps.
- Device-key migration path must be defined early to avoid data loss when progress moves to authenticated profiles.
- Admin surface expansion could reintroduce `/admin` performance issues; ensure pagination/search requirements are part of the spec.
- Progress analytics will require careful messaging to avoid privacy concerns; coordinate documentation with roadmap updates.
- Supabase Security Advisor now flags the lack of per-user RLS on canonical curriculum/progress tables; capture remediation steps for these once authenticated learner work (AUTH-003+) re-keys writes away from device-only storage so we can layer owner policies without blocking service-role pipelines.

## Documentation & Tracking

- Keep AUTH/PROG entries in `docs/references/ISSUE_TRACKER.md` up to date as scope solidifies.
- Update `docs/MASTER_PLAN.md` once auth milestones are scheduled and removed scope is logged.
- Refresh `docs/TESTING_GUIDE.md` after auth/progress smoke tests are drafted.
- Link any new migrations or policies in `docs/references/SCHEMA_DECISIONS.md`.

## Next Implementation Tasks

1. AUTH-001 groundwork – seeds for Supabase magic-link auth, environment wiring, and basic login UI scaffolding.
2. PROG-001 – implement progress persistence schema + API surface (device-key coexistence + feature flags).
3. PROG-002 – wire learner UI to the new progress endpoints and surface basic admin insights.
4. Deferred backlog (AUTH-002 / ADM-006) – admin invites and `/admin/users` console remain out of scope unless roadmap changes.

## Session Log

- 2025-11-17: Archived ADM-002 session and kicked off media roadmap planning focused on storage, API surface, and auth alignment.
- 2025-11-17: Broke down MEDIA-001→005 deliverables and documented planning artefacts required before implementation starts.
- 2025-11-17: Rescoped media MVP to admin-only uploads, dropping contributor moderation until after launch.
- 2025-11-17: Captured MEDIA-001 rollout/rollback procedures and MEDIA-002 implementation checklist to unblock upcoming migrations and backend work.
- 2025-11-18: Applied migration `0011_media_admin_mvp.sql` to Supabase and added automated smoke `npm run test:media001` to validate admin-only RLS.
- 2025-11-18: Updated migration guards to suppress redundant drop notices and revalidated (`npx supabase db push --yes`, `npm run test:media001`).
- 2025-11-18: Shipped MEDIA-002 admin media API (`POST/GET/DELETE /admin/media`, signed URL helper), refreshed docs, and added `npm run test:media002` smoke coverage.
- 2025-11-18: Extended rate limiting for admin media create/delete buckets, documented env knobs, and updated smoke coverage to assert `RATE_LIMITED` responses.
- 2025-11-18: Delivered `/admin/media` workspace (filters, search, detail drawer, delete + signed URL actions) and wired admin dashboard link.
- 2025-11-18: Implemented MEDIA-002 creation drawer with automatic Supabase upload hand-off and external link validation (upload + external happy paths + error surfacing).
- 2025-11-18: Added Concept Manager media panel with attachment list, creation drawer shortcut, and inline delete to keep concepts free of orphaned assets.
- 2025-11-18: Cleared lingering Svelte accessibility warnings (`npm run frontend:check` now passes clean), localised required-field toasts, and upsized the learner gallery modal for embedded media.
- 2025-11-18: Upgraded `/admin/media` table with checkbox multi-select, bulk delete workflow, and inline media preview (signed URLs + external embeds) while keeping concept attachments in sync.
- 2025-11-18: Upgraded `/admin/media` table with checkbox multi-select, bulk delete workflow, and inline media preview (signed URLs + external embeds) while keeping concept attachments in sync.
- 2025-11-19: Routed concept media fetches through a configurable public API base so GitHub Pages hits the hosted Express app (updates in `frontend/src/lib/api/media.ts`, runtime config, and deploy workflow). Documented the change in infra notes.
- 2025-11-19: Updated GitHub Pages deploy pipeline to inject both admin and public API bases (`deploy-frontend-gh-pages.yml`) ensuring runtime config stays aligned after future key rotations.
- 2025-11-19: Media renders correctly in production; next session will tackle the “Nežinoma sąvoka” placeholder in the `/admin/media` concept column.
- 2025-11-20: Resolved admin media filter desync after reassignment (`applyUpdatedAsset` now prunes items + refreshes list), refreshed documentation (API contracts, testing guide, admin setup, infra index), and noted new QA coverage for modal preview + delete confirmation.
- 2025-11-20: Captured media MVP wrap-up across README/docs, refreshed session goals toward auth planning, and re-ran media smoke tests after dropping deprecated payload fields.
- 2025-11-25: Cleared legacy branches, recorded scope removals, and pivoted session goals to authentication, admin user management, and progress tracking.
- 2025-11-25: Cut branch `feature/auth-implementation` after committing the auth execution plan; beginning Step 0 pre-flight (env audit, guard baseline, device-key sampling).
- 2025-11-26: Delivered `/api/v1/auth/magic-link` + `/session`, wired the Svelte auth store + AppShell login/logout surfaces, and refreshed docs/tests with the new Supabase env + smoke coverage guidance.
- 2025-11-26: Refined AppShell user menu (single email surface, admin-only link visibility, anchored sign-out action) and documented Render include-path + env requirements ahead of the next deploy.
- 2025-11-21: Extended admin media uploads with automatic asset type detection (image/video/document), enforced a 10 MB cap, refreshed PDF preview fallbacks across admin/public views, and applied Supabase migration `0012_media_document_support.sql` via `supabase db push` followed by stack restart.

## Wrap-up Checklist (close when all items are complete)

- [ ] Auth implementation brief completed and linked from references.
- [ ] Admin user management spec documented and tracked.
- [ ] Progress tracking plan captured (schema + API).
- [ ] Scope change log (`docs/REMOVED_FROM_SCOPE.md`) populated and cross-referenced.
